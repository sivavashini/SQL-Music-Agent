def get_schema():
    return """
Database: Chinook Music Store

Table: Album
- AlbumId (INTEGER, Primary Key)
- Title (NVARCHAR)
- ArtistId (INTEGER, Foreign Key to Artist)

Table: Artist
- ArtistId (INTEGER, Primary Key)
- Name (NVARCHAR)

Table: Customer
- CustomerId (INTEGER, Primary Key)
- FirstName (NVARCHAR)
- LastName (NVARCHAR)
- Company (NVARCHAR)
- Address (NVARCHAR)
- City (NVARCHAR)
- State (NVARCHAR)
- Country (NVARCHAR)
- PostalCode (NVARCHAR)
- Phone (NVARCHAR)
- Fax (NVARCHAR)
- Email (NVARCHAR)
- SupportRepId (INTEGER, Foreign Key to Employee)

Table: Employee
- EmployeeId (INTEGER, Primary Key)
- LastName (NVARCHAR)
- FirstName (NVARCHAR)
- Title (NVARCHAR)
- ReportsTo (INTEGER, Foreign Key to Employee)
- BirthDate (DATETIME)
- HireDate (DATETIME)
- Address (NVARCHAR)
- City (NVARCHAR)
- State (NVARCHAR)
- Country (NVARCHAR)
- PostalCode (NVARCHAR)
- Phone (NVARCHAR)
- Fax (NVARCHAR)
- Email (NVARCHAR)

Table: Genre
- GenreId (INTEGER, Primary Key)
- Name (NVARCHAR)

Table: Invoice
- InvoiceId (INTEGER, Primary Key)
- CustomerId (INTEGER, Foreign Key to Customer)
- InvoiceDate (DATETIME)
- BillingAddress (NVARCHAR)
- BillingCity (NVARCHAR)
- BillingState (NVARCHAR)
- BillingCountry (NVARCHAR)
- BillingPostalCode (NVARCHAR)
- Total (NUMERIC)

Table: InvoiceLine
- InvoiceLineId (INTEGER, Primary Key)
- InvoiceId (INTEGER, Foreign Key to Invoice)
- TrackId (INTEGER, Foreign Key to Track)
- UnitPrice (NUMERIC)
- Quantity (INTEGER)

Table: MediaType
- MediaTypeId (INTEGER, Primary Key)
- Name (NVARCHAR)

Table: Playlist
- PlaylistId (INTEGER, Primary Key)
- Name (NVARCHAR)

Table: PlaylistTrack
- PlaylistId (INTEGER, Foreign Key to Playlist)
- TrackId (INTEGER, Foreign Key to Track)

Table: Track
- TrackId (INTEGER, Primary Key)
- Name (NVARCHAR)
- AlbumId (INTEGER, Foreign Key to Album)
- MediaTypeId (INTEGER, Foreign Key to MediaType)
- GenreId (INTEGER, Foreign Key to Genre)
- Composer (NVARCHAR)
- Milliseconds (INTEGER)
- Bytes (INTEGER)
- UnitPrice (NUMERIC)
"""
